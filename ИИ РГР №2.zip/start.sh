#!/bin/bash
# Скрипт быстрого запуска RealEstate AI

echo "🏠 RealEstate AI - Запуск приложения"
echo "===================================="
echo ""

# Проверка Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 не найден. Установите Python 3.7+"
    exit 1
fi

echo "✅ Python найден: $(python3 --version)"

# Установка Flask
echo ""
echo "📦 Проверка зависимостей..."
pip install -q flask

# Инициализация БД (если не существует)
if [ ! -f "database.db" ]; then
    echo "🗄️  Инициализация базы данных..."
    python3 init_db.py
else
    echo "✅ База данных уже существует"
fi

echo ""
echo "🚀 Запуск приложения..."
echo "📍 Откройте в браузере: http://localhost:5000"
echo ""
echo "Для остановки нажмите Ctrl+C"
echo ""

# Запуск приложения
python3 app.py
